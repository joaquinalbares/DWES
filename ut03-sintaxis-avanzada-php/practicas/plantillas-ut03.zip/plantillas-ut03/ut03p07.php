<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT03 · P07: Conversor de divisas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · UT03 · P07: Conversor de divisas
    Solo contiene la estructura HTML y los estilos. Busca los comentarios TODO
    para saber dónde tienes que añadir el código PHP.
    Página autoprocesada: el formulario se envía a sí misma (action="").
    TODO (PHP, antes del DOCTYPE): recoge y valida los datos cuando la petición sea POST.
    TODO: guarda las tasas en un array asociativo: ['EUR' => 1.0, 'USD' => 1.0850, 'JPY' => 160.0].
-->
<section class="section">
    <div class="container" style="max-width: 500px;">
        <div class="box">
            <h1 class="title has-text-centered">
                <i class="fa fa-money"></i> Conversor de divisas
            </h1>

            <!-- TODO: muestra este aviso SOLO si hay un error -->
            <div class="notification is-danger">Mensaje de error de ejemplo.</div>

            <form action="" method="POST">
                <!-- TODO: formulario persistente, el value debe mostrar lo que envió el usuario (escapado) -->
                <div class="field">
                    <label class="label" for="cantidad">Convertir:</label>
                    <div class="control has-icons-left">
                        <input class="input" type="number" id="cantidad" name="cantidad" step="0.01" min="0" placeholder="100.00" required>
                        <span class="icon is-small is-left"><i class="fa fa-calculator"></i></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label" for="de">De:</label>
                    <div class="control has-icons-left">
                        <div class="select is-fullwidth">
                            <!-- TODO: añade 'selected' a la opción que eligió el usuario -->
                            <select name="de" id="de">
                                <option value="EUR">Euro (€)</option>
                                <option value="USD">Dólar estadounidense ($)</option>
                                <option value="JPY">Yen japonés (¥)</option>
                            </select>
                        </div>
                        <span class="icon is-small is-left"><i class="fa fa-globe"></i></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label" for="a">A:</label>
                    <div class="control has-icons-left">
                        <div class="select is-fullwidth">
                            <!-- TODO: añade 'selected' a la opción que eligió el usuario -->
                            <select name="a" id="a">
                                <option value="EUR">Euro (€)</option>
                                <option value="USD">Dólar estadounidense ($)</option>
                                <option value="JPY">Yen japonés (¥)</option>
                            </select>
                        </div>
                        <span class="icon is-small is-left"><i class="fa fa-exchange"></i></span>
                    </div>
                </div>
                <div class="field mt-4">
                    <button class="button is-link is-fullwidth" type="submit"><i class="fa fa-refresh mr-2"></i> Convertir</button>
                </div>
            </form>

            <!-- TODO: muestra el resultado con sprintf() SOLO tras una conversión correcta -->
            <div class="notification is-success is-light mt-4 has-text-centered">
                <p class="is-size-5"><strong>340.00 EUR = 368.90 USD</strong></p>
            </div>
        </div>
    </div>
</section>
</body>

</html>
