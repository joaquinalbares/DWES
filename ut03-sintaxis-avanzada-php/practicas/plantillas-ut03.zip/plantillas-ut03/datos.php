<?php
$categorias = ['Informática', 'Telefonía', 'Audio', 'Hogar'];

$productos = [
    ['nombre' => 'Portátil 15"',          'categoria' => 'Informática', 'precio' => 749.00, 'stock' => 5],
    ['nombre' => 'Ratón inalámbrico',     'categoria' => 'Informática', 'precio' => 19.90,  'stock' => 0],
    ['nombre' => 'Monitor 27"',           'categoria' => 'Informática', 'precio' => 229.00, 'stock' => 3],
    ['nombre' => 'Smartphone 128 GB',     'categoria' => 'Telefonía',   'precio' => 399.00, 'stock' => 8],
    ['nombre' => 'Funda de silicona',     'categoria' => 'Telefonía',   'precio' => 9.95,   'stock' => 25],
    ['nombre' => 'Auriculares Bluetooth', 'categoria' => 'Audio',       'precio' => 59.00,  'stock' => 0],
    ['nombre' => 'Altavoz portátil',      'categoria' => 'Audio',       'precio' => 45.50,  'stock' => 12],
    ['nombre' => 'Robot aspirador',       'categoria' => 'Hogar',       'precio' => 199.00, 'stock' => 2],
    ['nombre' => 'Cafetera de cápsulas',  'categoria' => 'Hogar',       'precio' => 79.99,  'stock' => 0],
];
