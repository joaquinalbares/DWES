<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT03 · P03: Calculadora de la letra del DNI</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · UT03 · P03: Calculadora de la letra del DNI
    Solo contiene la estructura HTML y los estilos. Busca los comentarios TODO
    para saber dónde tienes que añadir el código PHP.
    Página autoprocesada: el formulario se envía a sí misma (action="").
    TODO (PHP, antes del DOCTYPE): recoge y valida los datos cuando la petición sea POST.
    TODO: escribe la función calcularLetraDNI(int $numero): string.
-->
<section class="section">
    <div class="container" style="max-width: 550px;">
        <div class="box">
            <h1 class="title has-text-centered">
                <i class="fa fa-id-card"></i> Calculadora de la letra del DNI
            </h1>

            <!-- TODO: muestra este aviso SOLO si hay un error -->
            <div class="notification is-danger">Mensaje de error de ejemplo.</div>

            <form action="" method="POST">
                <!-- TODO: formulario persistente, el value debe mostrar lo que envió el usuario (escapado) -->
                <div class="field">
                    <label class="label" for="numero">Número de DNI (sin letra):</label>
                    <div class="control has-icons-left">
                        <input class="input" type="number" id="numero" name="numero" placeholder="12345678" required>
                        <span class="icon is-small is-left"><i class="fa fa-hashtag"></i></span>
                    </div>
                </div>
                <div class="field is-grouped mt-4">
                    <div class="control is-expanded">
                        <button class="button is-link is-fullwidth" type="submit"><i class="fa fa-calculator mr-2"></i> Calcular</button>
                    </div>
                    <div class="control">
                        <a href="" class="button is-light">Borrar</a>
                    </div>
                </div>
            </form>

            <!-- TODO: muestra el resultado SOLO si el número es válido -->
            <div class="notification is-info is-light mt-4 has-text-centered">
                <p class="is-size-5">DNI completo: <strong>12345678Z</strong></p>
            </div>
        </div>
    </div>
</section>
</body>

</html>
