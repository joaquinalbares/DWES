<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT03 · P02: Datos recibidos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · UT03 · P02: Datos recibidos
    Solo contiene la estructura HTML y los estilos. Busca los comentarios TODO
    para saber dónde tienes que añadir el código PHP.
    Muestra en una tabla todo lo que llega desde ut03p02.php.
-->
<section class="section">
    <div class="container" style="max-width: 800px;">
        <!-- TODO (PHP, antes del DOCTYPE):
             1. Si no se ha llegado por POST, redirige a ut03p02.php.
             2. Recoge cada campo de $_POST (los checkbox y el select múltiple llegan como array: usa ?? []).
             3. Del fichero muestra nombre, tamaño y tipo a partir de $_FILES['fichero'].
             4. La contraseña se muestra enmascarada (•••). -->
        <div class="card">
            <header class="card-header has-background-success">
                <p class="card-header-title has-text-white">
                    <i class="fa fa-database mr-2"></i> Datos recibidos del formulario
                </p>
            </header>
            <div class="card-content">
                <table class="table is-bordered is-striped is-hoverable is-fullwidth">
                    <thead>
                        <tr class="has-background-link-light">
                            <th>Elemento</th>
                            <th>Valor recibido</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><strong>Campo oculto (HIDDEN)</strong></td>
                            <td><!-- TODO --> <code>XYZ987654321</code></td>
                        </tr>
                        <tr>
                            <td><strong>Cadena a buscar (TEXT)</strong></td>
                            <td><!-- TODO --> valor por defecto</td>
                        </tr>
                        <tr>
                            <td><strong>Sexo (RADIO)</strong></td>
                            <td><!-- TODO --> Mujer</td>
                        </tr>
                        <tr>
                            <td><strong>Extras (CHECKBOX)</strong></td>
                            <td><!-- TODO --> Garaje, Piscina</td>
                        </tr>
                        <tr>
                            <td><strong>Fichero (FILE)</strong></td>
                            <td><!-- TODO --> Archivo: <strong>foto.jpg</strong> (24 512 bytes, tipo: image/jpeg)</td>
                        </tr>
                        <tr>
                            <td><strong>Contraseña (PASSWORD)</strong></td>
                            <td><!-- TODO --> •••••••• <em>(enmascarada)</em></td>
                        </tr>
                        <tr>
                            <td><strong>Color (SELECT simple)</strong></td>
                            <td><!-- TODO --> <span class="tag is-info">Rojo</span></td>
                        </tr>
                        <tr>
                            <td><strong>Idiomas (SELECT múltiple)</strong></td>
                            <td><!-- TODO --> Español, Inglés</td>
                        </tr>
                        <tr>
                            <td><strong>Comentario (TEXTAREA)</strong></td>
                            <td><!-- TODO --> Este artículo me parece...</td>
                        </tr>
                    </tbody>
                </table>
                <a href="ut03p02.php" class="button is-link is-outlined is-fullwidth">
                    <i class="fa fa-arrow-left mr-2"></i> Volver al formulario
                </a>
            </div>
        </div>
    </div>
</section>
</body>

</html>
