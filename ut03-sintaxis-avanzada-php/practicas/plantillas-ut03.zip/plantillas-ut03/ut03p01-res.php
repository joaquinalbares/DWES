<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT03 · P01: Resultados de la búsqueda</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · UT03 · P01: Resultados de la búsqueda
    Solo contiene la estructura HTML y los estilos. Busca los comentarios TODO
    para saber dónde tienes que añadir el código PHP.
    Muestra los datos recibidos de ut03p01.html.
-->
<section class="section">
    <div class="container" style="max-width: 600px;">
        <!-- TODO (PHP, antes del DOCTYPE):
             1. Si no se ha llegado por POST, redirige a ut03p01.html con header('Location: ...').
             2. Recoge 'texto', 'buscar_en' y 'genero' de $_POST y escápalos con htmlspecialchars().
             3. Convierte el valor de 'buscar_en' en un texto legible con match. -->
        <div class="card">
            <header class="card-header has-background-success">
                <p class="card-header-title has-text-white">
                    <i class="fa fa-check-circle mr-2"></i> Resultados del formulario
                </p>
            </header>
            <div class="card-content">
                <p class="subtitle is-5">Estos son los datos introducidos:</p>
                <div class="content">
                    <ul>
                        <li><strong>Texto de búsqueda:</strong> <!-- TODO --> rock and roll</li>
                        <li><strong>Buscar en:</strong> <!-- TODO --> Ambos campos</li>
                        <li><strong>Género:</strong> <!-- TODO --> Rock</li>
                    </ul>
                </div>
                <div class="field mt-5">
                    <a href="ut03p01.html" class="button is-link is-outlined is-fullwidth">
                        <i class="fa fa-arrow-left mr-2"></i> Nueva búsqueda
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
</body>

</html>
