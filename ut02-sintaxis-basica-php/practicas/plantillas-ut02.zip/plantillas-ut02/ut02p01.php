<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P01: Tarjeta de perfil</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p01.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Guarda en variables el nombre, el puesto, la biografía y la URL del perfil.
    El nombre y el enlace se generan con echo; el puesto y la biografía, con la etiqueta corta de impresión.
-->
<section class="section">
    <div class="container" style="max-width: 550px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-id-badge"></i> Tarjeta de perfil</h1>

            <div class="card">
                <div class="card-content">
                    <!-- TODO: genera este bloque con PHP -->
                    <h2 class="title is-4">Lucía Martínez</h2>
                    <!-- 2. Salida con la etiqueta corta de impresión (signo de interrogación + igual) -->
                    <p class="subtitle is-6 has-text-grey"><!-- TODO -->Desarrolladora web</p>
                    <p><!-- TODO -->Me encanta programar en PHP y diseñar interfaces con Bulma. Vivo en Cieza.</p>
                    <!-- TODO: genera este bloque con PHP -->
                    <a class="button is-link mt-4" href="https://github.com/luciamartinez" target="_blank"><i class="fa fa-github mr-2"></i> Ver perfil</a>
                </div>
            </div>

            <p class="help mt-4">Pulsa Ctrl+U: en el código fuente que recibe el navegador no queda ninguna etiqueta PHP.</p>
        </div>
    </div>
</section>
</body>

</html>
