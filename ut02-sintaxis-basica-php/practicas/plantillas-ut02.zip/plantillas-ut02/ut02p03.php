<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P03: Comillas simples y dobles</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p03.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Crea $producto y $precio y construye las seis frases. Escribe en un comentario
    la diferencia que observas entre comillas simples y dobles.
-->
<section class="section">
    <div class="container" style="max-width: 700px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-quote-left"></i> Comillas simples y dobles</h1>

            <table class="table is-bordered is-fullwidth">
                <thead>
                    <tr><th>Código</th><th>Resultado</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>'El producto es $producto'</code></td><td><!-- TODO -->El producto es $producto</td></tr>
                    <tr><td><code>"El producto es $producto"</code></td><td><!-- TODO -->El producto es Portátil</td></tr>
                    <tr><td><code>"Hay 3 {$producto}s en el almacén"</code></td><td><!-- TODO -->Hay 3 Portátils en el almacén</td></tr>
                    <tr><td><code>'El ' . $producto . ' cuesta ' . $precio . ' €'</code></td><td><!-- TODO -->El Portátil cuesta 799.99 €</td></tr>
                    <tr><td><code>"… usa \$producto"</code></td><td><!-- TODO -->Para escribir el símbolo del dólar usa $producto</td></tr>
                    <tr><td><code>&lt;&lt;&lt;TXT … TXT;</code> (heredoc)</td><td><!-- TODO -->Oferta: Portátil a 799.99 €<br />
¡Solo hoy!</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
</body>

</html>
