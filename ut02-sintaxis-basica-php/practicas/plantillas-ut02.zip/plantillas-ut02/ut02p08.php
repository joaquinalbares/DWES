<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P08: Panel de información del servidor</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p08.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Activa las directivas (ini_set, error_reporting, zona horaria) y recoge los datos de PHP
    y de $_SERVER. Recuerda escapar con htmlspecialchars() y usar ?? por si falta una clave.
-->
<section class="section">
    <div class="container" style="max-width: 1000px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-server"></i> Panel de información del servidor</h1>

            <div class="columns">
                <div class="column">
                    <h2 class="title is-5"><i class="fa fa-cog"></i> PHP</h2>
                    <table class="table is-fullwidth is-narrow">
                        <tbody>
                            <tr><th>Fecha y hora</th><td><!-- TODO -->01/11/2026 22:32:47</td></tr>
                            <tr><th>Versión de PHP</th><td><!-- TODO -->8.3.6</td></tr>
                            <tr><th>Sistema operativo</th><td><!-- TODO -->Linux</td></tr>
                            <tr><th>Interfaz (SAPI)</th><td><!-- TODO -->cli-server</td></tr>
                            <tr><th>memory_limit</th><td><!-- TODO -->-1</td></tr>
                            <tr><th>upload_max_filesize</th><td><!-- TODO -->2M</td></tr>
                            <tr><th>display_errors</th><td><!-- TODO -->'' → <!-- TODO -->'1'</td></tr>
                        </tbody>
                    </table>
                </div>
                <div class="column">
                    <h2 class="title is-5"><i class="fa fa-exchange"></i> Petición ($_SERVER)</h2>
                    <table class="table is-fullwidth is-narrow">
                        <tbody>
                            <tr><th>HTTP_HOST</th><td><!-- TODO -->ut02.test</td></tr>
                            <tr><th>REQUEST_METHOD</th><td><!-- TODO -->GET</td></tr>
                            <tr><th>REMOTE_ADDR</th><td><!-- TODO -->127.0.0.1</td></tr>
                            <tr><th>SERVER_SOFTWARE</th><td><!-- TODO -->PHP/8.3.6 (Development Server)</td></tr>
                            <tr><th>SCRIPT_FILENAME</th><td><code><!-- TODO -->/home/alumno/Herd/ut02/ut02p08.php</code></td></tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <h2 class="title is-6">HTTP_USER_AGENT</h2>
            <!-- El navegador puede enviar cualquier texto: SIEMPRE se escapa -->
            <pre style="white-space: pre-wrap;"><!-- TODO -->Mozilla/5.0 (X11; Linux x86_64) Firefox/131.0</pre>
        </div>
    </div>
</section>
</body>

</html>
