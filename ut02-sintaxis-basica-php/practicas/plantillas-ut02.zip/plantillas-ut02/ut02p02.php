<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P02: Estilos generados desde PHP</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p02.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Calcula el segundo actual, el tono (segundo × 6), los dos colores hsl(), el porcentaje
    del minuto y la hora. Después insértalos en los atributos style con la etiqueta corta de impresión.
-->
<section class="section">
    <div class="container" style="max-width: 550px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-paint-brush"></i> Estilos generados desde PHP</h1>

            <!-- El atributo style se rellena desde PHP: el navegador solo ve el CSS ya calculado -->
            <!-- TODO: los valores de los atributos de esta etiqueta se calculan con PHP -->
            <div class="p-5 mb-4" style="background-color: hsl(282, 70%, 85%); border: 3px solid hsl(282, 70%, 40%); border-radius: 8px;">
                <p class="is-size-4 has-text-weight-bold">Hora del servidor: <!-- TODO -->22:32:47</p>
                <p>Tono actual: <!-- TODO -->282°</p>
            </div>

            <p class="mb-2">Progreso del minuto: <!-- TODO -->80 %</p>
            <div style="background: #eee; border-radius: 4px;">
                <!-- TODO: los valores de los atributos de esta etiqueta se calculan con PHP -->
                <div style="width: 80%; height: 1rem; background-color: hsl(282, 70%, 40%); border-radius: 4px;"></div>
            </div>

            <p class="help mt-4">Recarga la página (F5) varias veces y compara el atributo style con Ctrl+U.</p>
        </div>
    </div>
</section>
</body>

</html>
