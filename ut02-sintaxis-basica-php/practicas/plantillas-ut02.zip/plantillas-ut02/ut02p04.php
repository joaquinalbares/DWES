<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P04: Ficha de datos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p04.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Define APP_NAME (define) y APP_VERSION (const) y cuatro variables, una de cada tipo escalar.
-->
<section class="section">
    <div class="container" style="max-width: 700px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-address-card"></i> Ficha de datos</h1>

            <p class="subtitle is-6"><!-- TODO -->Gestor de alumnado · versión <!-- TODO -->1.2.0</p>

            <!-- Interpolación con comillas dobles -->
            <div class="notification is-info is-light">
                <!-- TODO -->Carlos Ruiz tiene 19 años y mide 1.78 m.
            </div>

            <table class="table is-bordered is-striped is-fullwidth">
                <thead>
                    <tr><th>Variable</th><th>Valor</th><th>Tipo (gettype)</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>$nombre</code></td><td><!-- TODO -->Carlos Ruiz</td><td><!-- TODO -->string</td></tr>
                    <tr><td><code>$edad</code></td><td><!-- TODO -->19</td><td><!-- TODO -->integer</td></tr>
                    <tr><td><code>$altura</code></td><td><!-- TODO -->1.78</td><td><!-- TODO -->double</td></tr>
                    <!-- echo de true muestra "1" y de false no muestra nada: var_export() enseña el valor real -->
                    <tr><td><code>$activo</code></td><td><!-- TODO -->true</td><td><!-- TODO -->boolean</td></tr>
                    <tr><td><code>APP_VERSION</code></td><td><!-- TODO -->1.2.0</td><td><!-- TODO -->string</td></tr>
                </tbody>
            </table>

            <h2 class="title is-5">Salida de var_dump()</h2>
            <pre><!-- TODO -->string(11) "Carlos Ruiz"
int(19)
float(1.78)
bool(true)</pre>
        </div>
    </div>
</section>
</body>

</html>
