<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P07: Conversión de tipos y funciones integradas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p07.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Prepara cada conversión y cada llamada a función en una variable y muéstrala en la tabla.
-->
<section class="section">
    <div class="container" style="max-width: 850px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-exchange"></i> Conversión de tipos y funciones integradas</h1>

            <h2 class="title is-5">Conversiones</h2>
            <table class="table is-bordered is-striped is-fullwidth">
                <thead>
                    <tr><th>Expresión</th><th>Resultado</th><th>Tipo</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>'10' + '5.5'</code></td><td><!-- TODO -->15.5</td><td><!-- TODO -->double</td></tr>
                    <tr><td><code>(int) '3.99'</code></td><td><!-- TODO -->3</td><td><!-- TODO -->integer</td></tr>
                    <tr><td><code>(float) '19,90'</code></td><td><!-- TODO -->19.0</td><td><!-- TODO -->double</td></tr>
                    <tr><td><code>(float) str_replace(',', '.', '19,90')</code></td><td><!-- TODO -->19.9</td><td><!-- TODO -->double</td></tr>
                    <tr><td><code>intval('1A', 16)</code></td><td><!-- TODO -->26</td><td><!-- TODO -->integer</td></tr>
                    <tr><td><code>(bool) '0'</code></td><td><!-- TODO -->false</td><td><!-- TODO -->boolean</td></tr>
                    <tr><td><code>(bool) '0.0'</code></td><td><!-- TODO -->true</td><td><!-- TODO -->boolean</td></tr>
                    <tr><td><code>is_numeric('19,90')</code></td><td><!-- TODO -->false</td><td><!-- TODO -->boolean</td></tr>
                </tbody>
            </table>

            <h2 class="title is-5">Funciones de cadenas, números y fechas</h2>
            <table class="table is-bordered is-striped is-fullwidth">
                <thead>
                    <tr><th>Función</th><th>Resultado</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>trim('  ñandú veloz  ')</code></td><td>"<!-- TODO -->ñandú veloz"</td></tr>
                    <tr><td><code>strlen()</code> / <code>mb_strlen()</code></td><td><!-- TODO -->13 bytes / <!-- TODO -->11 caracteres</td></tr>
                    <tr><td><code>mb_strtoupper()</code></td><td><!-- TODO -->ÑANDÚ VELOZ</td></tr>
                    <tr><td><code>mb_convert_case(…, MB_CASE_TITLE)</code></td><td><!-- TODO -->Ñandú Veloz</td></tr>
                    <tr><td><code>str_pad('3', 5, '0', STR_PAD_LEFT)</code></td><td><!-- TODO -->00003</td></tr>
                    <tr><td><code>round(2.675, 2)</code></td><td><!-- TODO -->2.68</td></tr>
                    <tr><td><code>number_format(3 * 19.9, 2, ',', '.')</code></td><td><!-- TODO -->59,70 €</td></tr>
                    <tr><td><code>max(4, 17, 9)</code></td><td><!-- TODO -->17</td></tr>
                    <tr><td><code>date('d/m/Y')</code></td><td><!-- TODO -->01/11/2026</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
</body>

</html>
