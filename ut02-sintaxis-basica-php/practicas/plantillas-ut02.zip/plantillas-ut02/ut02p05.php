<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P05: Calculadora aritmética</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p05.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Declara $num1 = 17 y $num2 = 5 y calcula cada operación en una variable.
-->
<section class="section">
    <div class="container" style="max-width: 800px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-calculator"></i> Calculadora aritmética</h1>

            <p class="subtitle is-6">Operandos: <strong>$num1 = <!-- TODO -->17</strong> y <strong>$num2 = <!-- TODO -->5</strong></p>

            <div class="columns">
                <div class="column">
                    <h2 class="title is-5">Operadores aritméticos</h2>
                    <div class="content">
                        <ul>
                            <li>Suma: <!-- TODO -->17 + <!-- TODO -->5 = <strong><!-- TODO -->22</strong></li>
                            <li>Resta: <!-- TODO -->17 − <!-- TODO -->5 = <strong><!-- TODO -->12</strong></li>
                            <li>Multiplicación: <!-- TODO -->17 × <!-- TODO -->5 = <strong><!-- TODO -->85</strong></li>
                            <li>División: <!-- TODO -->17 / <!-- TODO -->5 = <strong><!-- TODO -->3.4</strong></li>
                            <li>División entera (intdiv): <strong><!-- TODO -->3</strong></li>
                            <li>Resto (%): <strong><!-- TODO -->2</strong></li>
                            <li>Potencia (**): <!-- TODO -->17<sup><!-- TODO -->5</sup> = <strong><!-- TODO -->1.419.857</strong></li>
                        </ul>
                    </div>
                </div>
                <div class="column">
                    <h2 class="title is-5">Asignación e incremento</h2>
                    <div class="content">
                        <ul>
                            <li>10, += 5, *= 2, −= 4, /= 2 → <strong><!-- TODO -->13</strong></li>
                            <li>++$contador (con $contador = 1) → <strong><!-- TODO -->2</strong></li>
                            <li>$contador++ (después) → <strong><!-- TODO -->2</strong>, y $contador queda en <strong><!-- TODO -->3</strong></li>
                            <li>2 + 3 * 4 = <strong><!-- TODO -->14</strong></li>
                            <li>(2 + 3) * 4 = <strong><!-- TODO -->20</strong></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</body>

</html>
