<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P10: Factura de un trabajador autónomo</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p10.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Define IVA y RETENCION_IRPF, las variables globales y la función
    calcularFactura(int $horas, float &$base): float. Después, prueba copia frente a referencia.
-->
<section class="section">
    <div class="container" style="max-width: 650px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-file-text-o"></i> Factura de un trabajador autónomo</h1>

            <table class="table is-fullwidth">
                <tbody>
                    <tr><th>Tarifa por hora</th><td class="has-text-right"><!-- TODO -->25,50 €</td></tr>
                    <tr><th>Horas trabajadas</th><td class="has-text-right"><!-- TODO -->160 h</td></tr>
                    <tr><th>Base imponible (rellenada por referencia)</th><td class="has-text-right"><!-- TODO -->4.080,00 €</td></tr>
                    <tr><th>+ IVA (<!-- TODO -->21 %)</th><td class="has-text-right has-text-success"><!-- TODO -->856,80 €</td></tr>
                    <tr><th>− Retención IRPF (<!-- TODO -->15 %)</th><td class="has-text-right has-text-danger"><!-- TODO -->612,00 €</td></tr>
                    <tr class="has-background-light"><th class="is-size-5">TOTAL FACTURA</th><td class="has-text-right is-size-5 has-text-weight-bold"><!-- TODO -->4.324,80 €</td></tr>
                </tbody>
            </table>

            <h2 class="title is-5">Copia frente a referencia</h2>
            <div class="content">
                <ul>
                    <li><code>$original</code> = <!-- TODO -->500</li>
                    <li><code>$copia = $original</code> → <!-- TODO -->100 (no cambia)</li>
                    <li><code>$referencia = &amp;$original</code> y luego <code>$referencia = 500</code> → <!-- TODO -->500</li>
                </ul>
            </div>
        </div>
    </div>
</section>
</body>

</html>
