<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P09: Ámbito de las variables</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p09.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Escribe las funciones sinGlobal(), conGlobal(), conArrayGlobals(), contadorNormal()
    e incrementar_visitas(), y llama 5 veces a cada contador.
-->
<section class="section">
    <div class="container" style="max-width: 800px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-crosshairs"></i> Ámbito de las variables</h1>

            <h2 class="title is-5">Local y global</h2>
            <table class="table is-bordered is-fullwidth">
                <thead>
                    <tr><th>Función</th><th>Devuelve</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>sinGlobal()</code></td><td><!-- TODO -->(no existe $mensaje dentro de la función)</td></tr>
                    <tr><td><code>conGlobal()</code> (con <code>global</code>)</td><td><!-- TODO -->Hola desde el ámbito global</td></tr>
                    <tr><td><code>conArrayGlobals()</code> (con <code>$GLOBALS</code>)</td><td><!-- TODO -->Hola desde el ámbito global</td></tr>
                </tbody>
            </table>

            <h2 class="title is-5">Variables estáticas</h2>
            <table class="table is-bordered is-fullwidth has-text-centered">
                <thead>
                    <tr><th class="has-text-left">Llamada</th><th>1.ª</th><th>2.ª</th><th>3.ª</th><th>4.ª</th><th>5.ª</th></tr>
                </thead>
                <tbody>
                    <tr><td class="has-text-left"><code>contadorNormal()</code></td>
                        <td><!-- TODO -->1</td><td><!-- TODO -->1</td><td><!-- TODO -->1</td><td><!-- TODO -->1</td><td><!-- TODO -->1</td></tr>
                    <tr><td class="has-text-left"><code>incrementar_visitas()</code> (static)</td>
                        <td><!-- TODO -->1</td><td><!-- TODO -->2</td><td><!-- TODO -->3</td><td><!-- TODO -->4</td><td><!-- TODO -->5</td></tr>
                </tbody>
            </table>
        </div>
    </div>
</section>
</body>

</html>
