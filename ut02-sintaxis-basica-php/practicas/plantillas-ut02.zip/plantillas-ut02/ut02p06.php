<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UT02 · P06: Comparaciones débiles y estrictas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@1.0.4/css/bulma.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
<!--
    PLANTILLA · ut02p06.php
    Solo contiene la estructura HTML y los estilos. Los valores que ves son de EJEMPLO:
    los tuyos tiene que calcularlos PHP. Escribe la lógica al principio del fichero,
    antes del DOCTYPE, y sustituye cada TODO por el valor correspondiente.

    Declara $a = "50" y $b = 50. Muestra cada resultado con var_export(..., true)
    y escribe TÚ la explicación de la última columna.
-->
<section class="section">
    <div class="container" style="max-width: 850px;">
        <div class="box">
            <h1 class="title"><i class="fa fa-balance-scale"></i> Comparaciones débiles y estrictas</h1>

            <p class="subtitle is-6"><code>$a = "50"</code> (<!-- TODO -->string) · <code>$b = 50</code> (<!-- TODO -->integer)</p>

            <table class="table is-bordered is-fullwidth">
                <thead>
                    <tr><th>Expresión</th><th>Resultado</th><th>¿Por qué?</th></tr>
                </thead>
                <tbody>
                    <tr><td><code>$a == $b</code></td><td><code><!-- TODO -->true</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>$a === $b</code></td><td><code><!-- TODO -->false</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>$a != $b</code></td><td><code><!-- TODO -->false</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>$a !== $b</code></td><td><code><!-- TODO -->true</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>$a &lt;=&gt; $b</code></td><td><code><!-- TODO -->0</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>"abc" == 0</code></td><td><code><!-- TODO -->false</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>"1e3" == "1000"</code></td><td><code><!-- TODO -->true</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>null == false</code></td><td><code><!-- TODO -->true</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                    <tr><td><code>null === false</code></td><td><code><!-- TODO -->false</code></td>
                        <td><!-- TODO: tu explicación --></td></tr>
                </tbody>
            </table>

            <h2 class="title is-5">Con var_dump()</h2>
            <pre><!-- TODO -->bool(true)
bool(false)
bool(true)</pre>
        </div>
    </div>
</section>
</body>

</html>
