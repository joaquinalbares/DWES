# UT04 · P03 · Las cookies por dentro

**Nombre y apellidos:**

> Contesta debajo de cada apartado. Guarda las capturas en una carpeta `capturas/` y enlázalas así: `![Cookies de la P01](capturas/p03-1.png)`.

## 1. Ver

| Cookie | Valor | Caducidad | HttpOnly | Secure | SameSite |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |

Captura:

## 2. Seguir el intercambio

Cabecera `Cookie` de la petición:

```text

```

Cabeceras `Set-Cookie` de la respuesta:

```text

```

¿Coinciden los valores? ¿Por qué?

## 3. Manipular

- Con `visitas=abc`:
- Con `visitas=99999`:
- ¿Qué impide que alguien se invente su número de visitas?

## 4. Manipular el JSON

- Qué ves:
- Qué parte de tu código lo ha resuelto:

## 5. Sin navegador

Salida de la tercera orden:

```text

```

- Número de visita que aparece y por qué:
- `-i`:
- `-c`:
- `-b`:
- Contenido de `galletas.txt`:

## 6. Enviar lo que quieras

- Número que aparece:
- Conclusión:

## 7. JavaScript

- Resultado en la P01:
- Resultado en la P02:
- Explicación:
